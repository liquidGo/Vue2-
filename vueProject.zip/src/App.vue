<template>
  <div id="app">
    <home-view></home-view>
  </div>
</template>

<script>
import HomeView from './pages/home/Home.vue'
export default {
  name: 'App',
  components: {
    HomeView,
  }
}
</script>

<style lang="less">
</style>
