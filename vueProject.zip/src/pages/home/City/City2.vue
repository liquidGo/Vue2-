<template>
    <div>
        city123
    </div>
</template>

<script>
export default {
    name: 'City2',
    mounted(){
        console.log('dayinle');
    }
}
</script>

<style lang="stylus" scoped>
</style>